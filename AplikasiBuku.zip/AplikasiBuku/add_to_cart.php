<?php
include "koneksi.php";
session_start();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (!isset($_SESSION['user_id'])) {
        header('Location: login.php');
        exit;
    }

    $book_id = $_POST['book_id'];
    $quantity = $_POST['quantity'];
    $user_id = $_SESSION['user_id']; // Menggunakan session untuk menyimpan user_id

    // Ambil harga buku dari database
    $sql = "SELECT harga FROM books WHERE id = $book_id";
    $result = mysqli_query($koneksi, $sql);
    $book = mysqli_fetch_assoc($result);
    if (!$book) {
        echo "Book not found!";
        exit;
    }

    $total_price = $book['harga'] * $quantity;

    // Periksa apakah buku sudah ada di keranjang
    $sql = "SELECT * FROM purchase_history WHERE user_id = $user_id AND book_id = $book_id";
    $result = mysqli_query($koneksi, $sql);

    if (mysqli_num_rows($result) > 0) {
        // Jika buku sudah ada di keranjang, update kuantitasnya
        $sql = "UPDATE purchase_history SET quantity = quantity + $quantity, total_price = total_price + $total_price WHERE user_id = $user_id AND book_id = $book_id";
    } else {
        // Jika buku belum ada di keranjang, tambahkan sebagai item baru
        $sql = "INSERT INTO purchase_history (user_id, book_id, quantity, total_price) VALUES ($user_id, $book_id, $quantity, $total_price)";
    }

    if (mysqli_query($koneksi, $sql)) {
        echo "Book added to cart and purchase history updated successfully.";
        header('Location: index.php');
    } else {
        echo "Error: " . $sql . "<br>" . mysqli_error($koneksi);
    }
}
?>
