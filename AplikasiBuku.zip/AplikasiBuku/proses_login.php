<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    include 'koneksi.php';
    session_start();

    $email = $_POST['email'];
    $password = $_POST['password'];

    $sql = "SELECT * FROM login WHERE email = '$email'";
    $result = $koneksi->query($sql);

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        if (password_verify($password, $row['password'])) {
            $_SESSION['user_id'] = $row['id'];
            $_SESSION['user_name'] = $row['nama'];
            $_SESSION['user_email'] = $row['email'];
            header("Location: index.php");
            exit;
        } else {
            header("Location: login.php?error=Password%20salah");
            exit;
        }
    } else {
        header("Location: login.php?error=Email%20tidak%20ditemukan");
        exit;
    }

    $koneksi->close();
}
?>
