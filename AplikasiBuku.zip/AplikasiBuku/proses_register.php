<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    include 'koneksi.php';

    $nama = $_POST['nama'];
    $email = $_POST['email'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);

    $sql = "SELECT * FROM login WHERE email = '$email'";
    $result = $koneksi->query($sql);

    if ($result->num_rows > 0) {
        header("Location: register.php?email_error=Email%20sudah%20terpakai");
        exit;
    } else {
        $sql = "INSERT INTO login (nama, email, password) VALUES ('$nama', '$email', '$password')";
        if ($koneksi->query($sql) === TRUE) {
            header("Location: login.php");
            exit;
        } else {
            echo "Error: " . $sql . "<br>" . $koneksi->error;
        }
    }

    $koneksi->close();
}
?>
