<?php
include "koneksi.php";
session_start();

if (!isset($_GET['id'])) {
    header('Location: index.php');
    exit;
}

$book_id = $_GET['id'];
$sql = "SELECT * FROM books WHERE id = $book_id";
$result = mysqli_query($koneksi, $sql);
$book = mysqli_fetch_assoc($result);

if (!$book) {
    echo "Book not found!";
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $book['nama']; ?></title>
    <link rel="stylesheet" href="style.css?v=<?php echo time(); ?>" type="text/css">
    <link rel="stylesheet" href="https://unicons.iconscout.com/release/v4.0.0/css/line.css">
    <style>
        body {
            margin: 0;
            padding-top: 70px; /* Adjust this padding to the height of the header */
            background-color: honeydew;
            overflow: scroll;
            overflow-x: hidden;
        }
        
        .book-detail {
            font-family: Arial, sans-serif;
            display: flex;
            max-width: 1000px;
            margin: 50px auto;
            padding: 20px;
        }
        .book-detail img {
            width: 300px;
            height: auto;
            margin-right: 30px;
            box-shadow: -8px 8px 15px rgba(0, 0, 0, 0.5); 
        }
        .book-detail .details {
            flex: 1;
        }
        .book-detail .details h2 {
            margin-top: 0;
            font-size: 28px;
        }
        .book-detail .details p {
            margin-bottom: 10px;
            font-size: 18px;
        }
        .book-detail .details .price {
            font-size: 24px;
            color: #007bff;
            margin-bottom: 20px;
        }
        .book-detail .details form {
            display: flex;
            align-items: center;
        }
        .book-detail .details form input[type="number"] {
            width: 60px;
            padding: 10px;
            margin-right: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }
        .book-detail .details form input[type="submit"] {
            padding: 10px 20px;
            background-color: #007bff;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
        }
        .book-detail .details form input[type="submit"]:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
    <nav>
        <div class="container">
            <div class="logonstuff">
            <a href="index.php"><img src="photos/Logo.png" alt="" id="logo"></a>
                <div>
                    <p style="font-family: 'Playfair Display', serif;">Kategori</p>
                </div>
            </div>
            <div class="search-bar">
                <i class="uil uil-search"></i>
                <input type="text" placeholder="search..." id="search-item" onkeyup="search()">
            </div>
            <div class="button">
                <?php if(isset($_SESSION['user_name'])): ?>
                    <div class="profile-dropdown">
                        <i class="uil uil-user-circle profile-icon"></i>
                        <div class="profile-menu">
                            <p>Hello, <?php echo $_SESSION['user_name']; ?></p>
                            <p><?php echo $_SESSION['user_email']; ?></p>
                            <a href="order_history.php">Order History</a>
                            <a href="logout.php" class="logout">Logout</a>
                        </div>
                    </div>
                    <a href="cart.php"><i class="uil uil-shopping-cart cart-icon"></i></a>
                <?php else: ?>
                    <a href="login.php" class="login">Login</a>
                    <button onclick="window.location.href='register.php'" class="Register">Register</button>
                <?php endif; ?>
            </div>
        </div>
    </nav>

    <div class="book-detail">
        <img src="<?php echo $book['foto']; ?>" alt="<?php echo $book['nama']; ?>">
        <div class="details">
            <h2><?php echo $book['nama']; ?></h2>
            <p><strong>Author:</strong> <?php echo $book['author']; ?></p>
            <p class="price">Harga: Rp <?php echo number_format($book['harga'], 0, ',', '.'); ?></p>
            <?php if (isset($_SESSION['user_name'])): ?>
                <form action="add_to_cart.php" method="post">
                    <input type="hidden" name="book_id" value="<?php echo $book['id']; ?>">
                    <label for="quantity">Quantity:</label>
                    <input type="number" id="quantity" name="quantity" value="1" min="1" required>
                    <input type="submit" value="Add To Cart">
                </form>
            <?php else: ?>
                <p>Please <a href="login.php">login</a> to add this book to your cart.</p>
            <?php endif; ?>
            <div class="book-details">
                <h3>Book Details</h3>
                <p><?php echo $book['deskripsi']; ?></p>
            </div>
        </div>
    </div>

    <div class="footer">
        <p>Website ini Dibuat oleh Petra Nathanael Kaligis XITKJ</p>
        <div>
            <i class="uil uil-youtube"></i>
            <i class="uil uil-instagram"></i>
            <i class="uil uil-github"></i>
        </div>
    </div>
</body>
</html>
