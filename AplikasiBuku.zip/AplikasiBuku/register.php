<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Register Page</title>
  <link rel="stylesheet" href="styleregister.css?v=<?php echo time(); ?>" type="text/css">
</head>
<body>
  <a href="index.php" class="back-button">Back</a>
  <div class="register-container">
    <h2>Halaman Register</h2>
    <form action="proses_register.php" method="post">
      <input type="text" name="nama" placeholder="Nama Lengkap" required>
      <input type="email" name="email" placeholder="Email" required>
      <?php if (isset($_GET['email_error'])): ?>
        <p class="error"><?php echo $_GET['email_error']; ?></p>
      <?php endif; ?>
      <input type="password" name="password" placeholder="Password" required>
      <input type="submit" name="submit" value="Register">
      <input type="reset" name="reset">
    </form>
  </div>
</body>
</html>
