<?php
include "koneksi.php";
session_start();

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

$user_id = $_SESSION['user_id'];

$sql = "SELECT * FROM payments WHERE id_pembelian = ?";
$stmt = mysqli_prepare($koneksi, $sql);
mysqli_stmt_bind_param($stmt, "i", $user_id);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Order History</title>
    <link rel="stylesheet" href="style.css?v=<?php echo time(); ?>" type="text/css">
    <link rel="stylesheet" href="https://unicons.iconscout.com/release/v4.0.0/css/line.css">
</head>
    <style>

        body {
            margin: 0;
            padding-top: 70px; /* Adjust this padding to the height of the header */
            background-color: honeydew;
            overflow: scroll;
            overflow-x: hidden;
        }

        .order-history {
            padding: 20px;
            max-width: 1200px;
            margin: 0 auto;
            font-family: Arial, sans-serif; 
        }

        .order-history h2 {
            margin-bottom: 20px;
            font-size: 30px;
            text-align: center;
        }

        .order-history table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }

        .order-history th, .order-history td {
            padding: 15px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }

        .order-history th {
            background-color: #f2f2f2;
        }

        .order-history tr:hover {
            background-color: #f1f1f1;
        }

        .order-history td {
            font-size: 16px;
        }

        .notification {
            padding: 15px;
            background-color: #4CAF50; /* Green */
            color: white;
            margin-bottom: 15px;
        }

        .notification.error {
            background-color: #f44336; /* Red */
        }

        
    </style>
<body>
    <nav>
        <div class="container">
            <div class="logonsearch">
                <div class="logonstuff">
                    <a href="index.php"><img src="photos/Logo.png" alt="" id="logo"></a>
                    <div>
                        <p>Kategori</p>
                    </div>
                </div>
                <div class="search-bar">
                    <i class="uil uil-search"></i>
                    <input type="text" placeholder="search..." id="search-item" onkeyup="search()">
                </div>
            </div>
            <div class="button">
                <?php if(isset($_SESSION['user_name'])): ?>
                    <div class="profile-dropdown">
                        <i class="uil uil-user-circle profile-icon"></i>
                        <div class="profile-menu">
                            <p>Hello, <?php echo $_SESSION['user_name']; ?></p>
                            <p><?php echo $_SESSION['user_email']; ?></p>
                            <a href="order_history.php">Order History</a>
                            <a href="logout.php" class="logout">Logout</a>
                        </div>
                    </div>
                    <a href="cart.php"><i class="uil uil-shopping-cart cart-icon"></i></a>
                <?php else: ?>
                    <a href="login.php" class="login">Login</a>
                    <button onclick="window.location.href='register.php'" class="Register">Register</button>
                <?php endif; ?>
            </div>
        </div>
    </nav>

    <div class="main-content">
        <div class="order-history">
            <h2>Order History</h2>
            <?php if (mysqli_num_rows($result) > 0): ?>
                <table>
                    <thead>
                        <tr>
                            <th>Payment ID</th>
                            <th>Payment Method</th>
                            <th>Amount</th>
                            <th>Date</th>
                            <th>Address</th>
                            <th>Phone Number</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($row = mysqli_fetch_assoc($result)): ?>
                            <tr>
                                <td><?php echo $row['id_pembayaran']; ?></td>
                                <td><?php echo $row['metode_pembayaran']; ?></td>
                                <td>Rp <?php echo number_format($row['jumlah'], 0, ',', '.'); ?></td>
                                <td><?php echo date('d M Y, H:i', strtotime($row['tanggal'])); ?></td>
                                <td><?php echo $row['alamat']; ?></td>
                                <td><?php echo $row['nomor_hp']; ?></td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <p>No orders found.</p>
            <?php endif; ?>
        </div>
    </div>

    <div class="footer">
        <p>Website ini Dibuat oleh Petra Nathanael Kaligis XITKJ</p>
        <div>
            <i class="uil uil-youtube"></i>
            <i class="uil uil-instagram"></i>
            <i class="uil uil-github"></i>
        </div>
    </div>
</body>
</html>

<?php
mysqli_stmt_close($stmt);
mysqli_close($koneksi);
?>
