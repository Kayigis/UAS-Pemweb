<?php
include "koneksi.php";
session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gatau</title>
    <link rel="stylesheet" href="style.css?v=<?php echo time(); ?>" type="text/css">
    <link rel="stylesheet" href="https://unicons.iconscout.com/release/v4.0.0/css/line.css">
</head>
<body>
        <?php
        session_start();
        if (isset($_SESSION['payment_status'])) {
            echo "<div class='notification'>" . $_SESSION['payment_status'] . "</div>";
            unset($_SESSION['payment_status']);
        }
        ?>
    <nav>
        <div class="container">
            <div class="logonsearch">
                <div class="logonstuff">
                    <a href="index.php"><img src="photos/Logo.png" alt="" id="logo"></a>
                    <div>
                        <p>Kategori</p>
                    </div>
                </div>

                <div class="search-bar">
                    <i class="uil uil-search"></i>
                    <input type="text" placeholder="search..." id="search-item" onkeyup="search()">
                </div>
            </div>

            <div class="button">
                <?php if(isset($_SESSION['user_name'])): ?>
                    <div class="profile-dropdown">
                        <i class="uil uil-user-circle profile-icon"></i>
                        <div class="profile-menu">
                            <p>Hello, <?php echo $_SESSION['user_name']; ?></p>
                            <p><?php echo $_SESSION['user_email']; ?></p>
                            <a href="order_history.php">Order History</a>
                            <a href="logout.php" class="logout">Logout</a>
                        </div>
                    </div>
                    <a href="cart.php"><i class="uil uil-shopping-cart cart-icon"></i></a>
                <?php else: ?>
                    <a href="login.php" class="login">Login</a>
                    <button onclick="window.location.href='register.php'" class="Register">Register</button>
                <?php endif; ?>
            </div>
        </div>
    </nav>

    <div class="main-content">
        <table>
            <tr>
                <td>
                    <div class="slider">
                        <div class="slides">
                            <input type="radio" name="radio-btn" id="radio1">
                            <input type="radio" name="radio-btn" id="radio2">
                            <input type="radio" name="radio-btn" id="radio3">

                            <div class="slide first">
                                <img src="photos/book1.png" alt="">
                            </div>
                            <div class="slide">
                                <img src="photos/book2.png" alt="">
                            </div>
                            <div class="slide">
                                <img src="photos/book3.png" alt="">
                            </div>

                            <div class="navigation-auto">
                                <div class="auto-btn1"></div>
                                <div class="auto-btn2"></div>
                                <div class="auto-btn3"></div>
                            </div>
                        </div>

                        <div class="navigation-manual">
                            <label for="radio1" class="manual-btn"></label>
                            <label for="radio2" class="manual-btn"></label>
                            <label for="radio3" class="manual-btn"></label>
                        </div>
                    </div>
                </td>
            </tr>

            <tr>
                <td>
                    <div class="stuff-container">
                        <div class="content-bar">
                            <div class="stuff">
                                <div class="images">
                                    <img src="photos/icon1.png" alt="" class="imges">
                                    <h4>Buku Baru</h4>
                                </div>
                                <div class="images">
                                    <img src="photos/icon2.png" alt="" class="imges">
                                    <h4>Buku Pilihan</h4>
                                </div>
                                <div class="images">
                                    <img src="photos/icon3.png" alt="" class="imges">
                                    <h4>Buku International</h4>
                                </div>
                                <div class="images">
                                    <img src="photos/icon4.png" alt="" class="imges">
                                    <h4>E-Book</h4>
                                </div>
                                <div class="images">
                                    <img src="photos/icon5.png" alt="" class="imges">
                                    <h4>Non-Books</h4>
                                </div>
                            </div>    
                        </div>      
                    </div>
                </td>
            </tr>

            <tr>
                <td>
                    <div class="books-section">
                        <p style="font-size: 40px; margin-left: 60px; margin-top: -30px; margin-bottom: 10px;">Rekomendasi Untukmu</p>
                        <div class="books">
                            <?php
                            $sql = "SELECT * FROM books";
                            $result = mysqli_query($koneksi, $sql);

                            if (mysqli_num_rows($result) > 0) {
                                while($row = mysqli_fetch_assoc($result)) {
                                    echo '<div class="book-item">';
                                    echo '<a href="book_detail.php?id='.$row['id'].'">';
                                    echo '<img src="'.$row['foto'].'" alt="" class="book-img">';
                                    echo '<div class="book-details">';
                                    echo '<h4 class="book-title">'.$row['nama'].'</h4>';
                                    echo '<p class="book-author">'.$row['author'].'</p>';
                                    echo '<p class="book-price">Rp '.number_format($row['harga'], 0, ',', '.').'</p>';
                                    echo '</div>';
                                    echo '</a>';
                                    echo '</div>';
                                }
                            } else {
                                echo 'No books available.';
                            }
                            ?>
                        </div>
                    </div>
                </td>
            </tr>
        </table>
    </div>

    <div class="footer">
        <p>Website ini Dibuat oleh Petra Nathanael Kaligis XITKJ</p>
        <div>
            <i class="uil uil-youtube"></i>
            <i class="uil uil-instagram"></i>
            <i class="uil uil-github"></i>
        </div>
    </div>

    <script src="script.js"></script>   
</body>
</html>
