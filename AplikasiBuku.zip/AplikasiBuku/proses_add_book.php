<?php
include "koneksi.php";

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nama = $_POST['nama'];
    $author = $_POST['author'];
    $harga = $_POST['harga'];
    $deskripsi = $_POST['deskripsi'];

    // Mengupload file foto ke directory photos
    $foto = $_FILES['foto']['name'];
    $target_dir = "photos/";
    $target_file = $target_dir . basename($foto);
    if (move_uploaded_file($_FILES['foto']['tmp_name'], $target_file)) {
        $foto_path = $target_file;
    } else {
        echo "Error uploading file.";
        exit;
    }

    // Menyimpan data ke database
    $sql = "INSERT INTO books (nama, author, harga, foto, deskripsi) VALUES ('$nama', '$author', $harga, '$foto_path', '$deskripsi')";
    if (mysqli_query($koneksi, $sql)) {
        echo "Book added successfully.";
        header('Location: index.php');
    } else {
        echo "Error: " . $sql . "<br>" . mysqli_error($koneksi);
    }
}
?>
