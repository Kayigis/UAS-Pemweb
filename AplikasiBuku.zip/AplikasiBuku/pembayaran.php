<?php
include "koneksi.php";
session_start();

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

$user_id = $_SESSION['user_id'];

$sql = "SELECT books.*, purchase_history.quantity FROM purchase_history 
        JOIN books ON purchase_history.book_id = books.id 
        WHERE purchase_history.user_id = $user_id";
$result = mysqli_query($koneksi, $sql);

$total = 0;
$books = [];
if (mysqli_num_rows($result) > 0) {
    while ($row = mysqli_fetch_assoc($result)) {
        $total += $row['harga'] * $row['quantity'];
        $books[] = $row;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Keranjang Belanja</title>
    <link rel="stylesheet" href="style.css?v=<?php echo time(); ?>" type="text/css">
    <link rel="stylesheet" href="https://unicons.iconscout.com/release/v4.0.0/css/line.css">
    <style>
        body {
            margin: 0;
            padding-top: 100px; /* Adjust this padding to the height of the header */
            background-color: honeydew;
            overflow: scroll;
            overflow-x: hidden;
        }

        .payment-container {
            font-family: Arial, sans-serif;
            margin-top: 14vh;
            padding: 20px;
            background-color: #fff;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }

        .payment-container h1 {
            text-align: center;
            margin-bottom: 20px;
        }

        .book-details {
            margin-bottom: 20px;
        }

        .book-item {
            background-color: #f9f9f9;
            padding: 10px;
            border-radius: 5px;
            margin-bottom: 10px;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
        }

        .book-item h3 {
            font-size: 18px;
            margin-bottom: 5px;
        }

        .book-item p {
            font-size: 16px;
            margin: 5px 0;
        }

        .form-group {
            margin-bottom: 15px;
        }

        .form-group label {
            display: block;
            margin-bottom: 5px;
            font-size: 16px;
        }

        .form-group input,
        .form-group select,
        .form-group textarea {
            width: 100%;
            padding: 10px;
            font-size: 16px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        .submit-button {
            display: block;
            width: 100%;
            padding: 10px;
            font-size: 18px;
            color: white;
            background-color: #007bff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s;
        }

        .submit-button:hover {
            background-color: #0056b3;
        }

        @media (max-width: 768px) {
            .payment-container {
                width: 90%;
            }
        }
    </style>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pembayaran</title>
    <link rel="stylesheet" href="style.css?v=<?php echo time(); ?>" type="text/css">
</head>
<body>

<?php
if (isset($_SESSION['payment_status'])) {
    echo "<div class='notification'>" . $_SESSION['payment_status'] . "</div>";
    unset($_SESSION['payment_status']);
}
?>

<nav>
        <div class="container">
            <div class="logonstuff">
            <a href="index.php"><img src="photos/Logo.png" alt="" id="logo"></a>
                <div>
                    <p style="font-family: 'Playfair Display', serif;">Kategori</p>
                </div>
            </div>
            <div class="search-bar">
                <i class="uil uil-search"></i>
                <input type="text" placeholder="search..." id="search-item" onkeyup="search()">
            </div>
            <div class="button">
                <?php if(isset($_SESSION['user_name'])): ?>
                    <div class="profile-dropdown">
                        <i class="uil uil-user-circle profile-icon"></i>
                        <div class="profile-menu">
                            <p>Hello, <?php echo $_SESSION['user_name']; ?></p>
                            <p><?php echo $_SESSION['user_email']; ?></p>
                            <a href="order_history.php">Order History</a>
                            <a href="logout.php" class="logout">Logout</a>
                        </div>
                    </div>
                    <a href="cart.php"><i class="uil uil-shopping-cart cart-icon"></i></a>
                <?php else: ?>
                    <a href="login.php" class="login">Login</a>
                    <button onclick="window.location.href='register.php'" class="Register">Register</button>
                <?php endif; ?>
            </div>
        </div>
    </nav>
    <div class="payment-container container">
        <h1>Detail Pembayaran</h1>
        <div class="book-details">
            <?php foreach ($books as $book): ?>
                <div class="book-item">
                    <h3><?php echo $book['nama']; ?></h3>
                    <p>Jumlah: <?php echo $book['quantity']; ?></p>
                    <p>Harga Total: Rp <?php echo number_format($book['harga'] * $book['quantity'], 0, ',', '.'); ?></p>
                </div>
            <?php endforeach; ?>
        </div>

        <form action="proses_payment.php" method="post">
            <div class="form-group">
                <label for="phone">Nomor Telepon:</label>
                <input type="text" id="phone" name="phone" required>
            </div>
            <div class="form-group">
                <label for="shipping">Jasa Pengiriman:</label>
                <select id="shipping" name="shipping" required>
                    <option value="J&T">J&T - Rp 10,000</option>
                    <option value="JNE">JNE - Rp 12,000</option>
                    <option value="GO-Send">GO-Send - Rp 15,000</option>
                </select>
            </div>
            <div class="form-group">
                <label for="address">Alamat:</label>
                <textarea id="address" name="address" required></textarea>
            </div>
            <div class="form-group">
                <label for="payment-method">Metode Pembayaran:</label>
                <select id="payment-method" name="payment_method" required>
                    <option value="Transfer Bank">Transfer Bank</option>
                    <option value="Kartu Kredit">Kartu Kredit</option>
                    <option value="OVO">OVO</option>
                    <option value="Gopay">Gopay</option>
                </select>
            </div>
            <div class="form-group">
                <label>Total:</label>
                <?php
                $shipping_cost = 10000; // Default J&T
                ?>
                <p id="total">Rp <?php echo number_format($total + $shipping_cost, 0, ',', '.'); ?></p>
                <input type="hidden" name="total_amount" value="<?php echo $total + $shipping_cost; ?>">
            </div>
            <button type="submit" class="submit-button">Bayar</button>
        </form>
    </div>

    <div class="footer">
        <p>Website ini Dibuat oleh Petra Nathanael Kaligis XITKJ</p>
        <div>
            <i class="uil uil-youtube"></i>
            <i class="uil uil-instagram"></i>
            <i class="uil uil-github"></i>
        </div>
    </div>

    <script>
        const shippingSelect = document.getElementById('shipping');
        const totalElement = document.getElementById('total');
        const totalInput = document.querySelector('input[name="total_amount"]');
        const totalAmount = <?php echo $total; ?>;
        const shippingCosts = {
            "J&T": 10000,
            "JNE": 12000,
            "GO-Send": 15000
        };

        shippingSelect.addEventListener('change', function() {
            const shippingCost = shippingCosts[this.value];
            const total = totalAmount + shippingCost;
            totalElement.textContent = 'Rp ' + total.toLocaleString('id-ID');
            totalInput.value = total;
        });
    </script>
</body>
</html>