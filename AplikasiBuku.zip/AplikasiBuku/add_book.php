<?php
include "koneksi.php";
session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Buku</title>
    <link rel="stylesheet" href="style.css?v=<?php echo time(); ?>" type="text/css">
    <link rel="stylesheet" href="https://unicons.iconscout.com/release/v4.0.0/css/line.css">
    <style>
        .main-content {
            max-width: 600px;
            margin: 50px auto;
            padding: 20px;
            background-color: #f9f9f9;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }
        .main-content h2 {
            text-align: center;
            margin-bottom: 20px;
        }
        .main-content form {
            display: flex;
            flex-direction: column;
        }
        .main-content form label {
            margin-bottom: 5px;
            font-weight: bold;
        }
        .main-content form input[type="text"],
        .main-content form input[type="number"],
        .main-content form input[type="file"],
        .main-content form textarea {
            margin-bottom: 15px;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
            font-size: 16px;
        }
        .main-content form input[type="submit"] {
            padding: 10px;
            background-color: #007bff;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
        }
        .main-content form input[type="submit"]:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
    <nav>
        <div class="container">
            <div class="logonsearch">
                <div class="logonstuff">
                <a href="index.php"><img src="photos/Logo.png" alt="" id="logo"></a>
                    <div>
                        <p>Kategori</p>
                    </div>
                </div>

                <div class="search-bar">
                    <i class="uil uil-search"></i>
                    <input type="text" placeholder="search..." id="search-item" onkeyup="search()">
                </div>
                
            </div>

           <div class="button">
                <?php if(isset($_SESSION['user_name'])): ?>
                    <div class="profile-dropdown">
                        <i class="uil uil-user-circle profile-icon"></i>
                        <div class="profile-menu">
                            <p>Hello, <?php echo $_SESSION['user_name']; ?></p>
                            <p><?php echo $_SESSION['user_email']; ?></p>
                            <a href="order_history.php">Order History</a>
                            <a href="logout.php" class="logout">Logout</a>
                        </div>
                    </div>
                    <a href="cart.php"><i class="uil uil-shopping-cart cart-icon"></i></a>
                <?php else: ?>
                    <a href="login.php" class="login">Login</a>
                    <button onclick="window.location.href='register.php'" class="Register">Register</button>
                <?php endif; ?>
            </div>
        </div>
    </nav>

    <div class="main-content">
        <h2>Tambah Buku Baru</h2>
        <form action="proses_add_book.php" method="post" enctype="multipart/form-data">
            <label for="nama">Nama Buku:</label>
            <input type="text" id="nama" name="nama" required>
            <label for="author">Author:</label>
            <input type="text" id="author" name="author" required>
            <label for="harga">Harga (Rp):</label>
            <input type="number" id="harga" name="harga" required>
            <label for="foto">Foto Cover Buku:</label>
            <input type="file" id="foto" name="foto" required>
            <label for="deskripsi">Deskripsi Buku:</label>
            <textarea id="deskripsi" name="deskripsi" rows="4" required></textarea>
            <input type="submit" value="Tambah Buku">
        </form>
    </div>

    <div class="footer">
        <p>Website ini Dibuat oleh Petra Nathanael Kaligis XITKJ</p>
        <div>
            <i class="uil uil-youtube"></i>
            <i class="uil uil-instagram"></i>
            <i class="uil uil-github"></i>
        </div>
    </div>
</body>
</html>
