<?php
include "koneksi.php";
session_start();

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

$user_id = $_SESSION['user_id'];
$book_id = $_POST['book_id'];

$sql = "DELETE FROM purchase_history WHERE user_id = $user_id AND book_id = $book_id";

if (mysqli_query($koneksi, $sql)) {
    header('Location: cart.php');
} else {
    echo "Error: " . mysqli_error($koneksi);
}
?>
