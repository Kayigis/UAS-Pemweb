<?php
include "koneksi.php";
session_start();

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

$user_id = $_SESSION['user_id'];
$phone = $_POST['phone'];
$shipping = $_POST['shipping'];
$address = $_POST['address'];
$payment_method = $_POST['payment_method'];
$total_amount = $_POST['total_amount'];

// Insert into payments table
$sql = "INSERT INTO payments (id_pembelian, metode_pembayaran, jumlah, tanggal, alamat, nomor_hp) VALUES (?, ?, ?, NOW(), ?, ?)";
$stmt = mysqli_prepare($koneksi, $sql);
mysqli_stmt_bind_param($stmt, "isiss", $user_id, $payment_method, $total_amount, $address, $phone);

if (mysqli_stmt_execute($stmt)) {
    // Clear cart after payment
    $clear_cart_sql = "DELETE FROM purchase_history WHERE user_id = ?";
    $clear_stmt = mysqli_prepare($koneksi, $clear_cart_sql);
    mysqli_stmt_bind_param($clear_stmt, "i", $user_id);
    mysqli_stmt_execute($clear_stmt);

    // Redirect to index.php with success notification
    $_SESSION['payment_status'] = "Pembayaran berhasil";
    header('Location: index.php');
} else {
    // Redirect back to pembayaran.php with failure notification
    $_SESSION['payment_status'] = "Pembayaran gagal: " . mysqli_error($koneksi);
    header('Location: pembayaran.php');
}

mysqli_close($koneksi);
?>
