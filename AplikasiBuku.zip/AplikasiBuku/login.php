<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Login Page</title>
  <link rel="stylesheet" href="stylelogin.css?v=<?php echo time(); ?>" type="text/css">
</head>
<body>
  <a href="index.php" class="back-button">Back</a>
  <div class="login-container">
    <h2>Halaman Login</h2>
    <form action="proses_login.php" method="post">
      <?php if (isset($_GET['error'])): ?>
        <p class="error"><?php echo $_GET['error']; ?></p>
      <?php endif; ?>
      <input type="email" name="email" placeholder="Email" required>
      <input type="password" name="password" placeholder="Password" required>
      <input type="submit" name="submit" value="Login">
      <input type="reset" name="reset">
    </form>
    <div class="register-section">
      <p>Belum mendaftar?</p>
      <button onclick="window.location.href='register.php'" class="Register">Register</button>
    </div>
  </div>
</body>
</html>
